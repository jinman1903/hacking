package dao.sell;


import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dto.BuyListDto;
import dto.Paging;
import dto.SellListDto;
import mybatis.SqlSessionBean;


public class SellPageDao {
	private static final Logger logger = LoggerFactory.getLogger(SellPageDao.class);
	private static SellPageDao dao = new SellPageDao();
	public static SellPageDao getInstance() {
		return dao;
	}
	
	public List<BuyListDto> list(Paging paging) {
		SqlSession mapperSession = SqlSessionBean.getSession();
		List<BuyListDto> list = mapperSession.selectList("SellPage.getList",paging);
		mapperSession.close();
		return list;
	}
	
	public int count(Map<String, String> map) {
		SqlSession mapperSession = SqlSessionBean.getSession();
		logger.info("map :{}",map);
		int result = mapperSession.selectOne("SellPage.count",map);
		mapperSession.close();
		return result;
	}
	
	public List<String> getCategories(){
		SqlSession sqlSession = SqlSessionBean.getSession();
		List<String> list= sqlSession.selectList("SellPage.getCategories");
		sqlSession.close();
		return list;
	}
	
	
	public List<String> getLocation(){
		SqlSession sqlSession = SqlSessionBean.getSession();
		List<String> list= sqlSession.selectList("SellPage.getLocation");
		sqlSession.close();
		return list;
	}
	public SellListDto getOne(String pdt_code) {
		SqlSession sqlSession = SqlSessionBean.getSession();
		SellListDto book = sqlSession.selectOne("SellPage.getOne",pdt_code);
		sqlSession.close();
		return book;
	}
	
	public int saleOne(BuyListDto buy) {
		SqlSession sqlSession = SqlSessionBean.getSession();
		int result=0;	
		try{
			result = sqlSession.insert("SellPage.sellOne",buy);
			sqlSession.update("SellPage.changeStatus",buy.getPdt_code());
			sqlSession.commit();
		}catch(Exception e) {
			logger.warn("상품 구매 오류 : {}",e.getMessage());
			sqlSession.rollback();
		}finally {
			sqlSession.close();
		}	
		return result;
	}
	
	public int write(SellListDto dto) {
		SqlSession mapperSession = SqlSessionBean.getSession();
		int result = mapperSession.insert("SellPage.write",dto);
		mapperSession.commit();
		mapperSession.close();
		return result;
	}


}